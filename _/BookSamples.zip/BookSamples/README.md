Java sample code for the book "jmonkeyengine 3.0 beginner's guide":
http://www.packtpub.com/jmonkeyengine-3-0-with-java-programming-beginners-guide/book
Includes multi-media assets, Ant script, and NetBeans IDE properties.