The numbered packes of mygame match the chapters in the book.
 
chapter 02 Creating your first 3D scene

chapter 03 Interacting with the user 

chapter 04 Adding character to our game 

chapter 05 Creating materials 

chapter 06 Having fun with physics 

chapter 07 Adding spark to our game 

chapter 08 Creating Landscapes 

chapter 09 Making yourself heard 

